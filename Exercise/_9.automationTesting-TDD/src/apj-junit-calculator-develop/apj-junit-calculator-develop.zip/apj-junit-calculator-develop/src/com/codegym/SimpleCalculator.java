package com.codegym;

public class SimpleCalculator {
    public static int add(int first, int second){
        return first + second;
    }

    public static int sub(int first, int second){
        return first - second;
    }
}
